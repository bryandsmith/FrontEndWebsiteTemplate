getName = function() {
     var fname = document.getElementById("fname").value;
     localStorage.setItem('f-name', fname);
};
setName = function() {
 document.getElementById("welcome").innerHTML = "Welcome to the family, " + localStorage.getItem('f-name') + "!";
};
showQuestions = function(div_id) {
    document.getElementById('Q1').style.display = 'none';
    document.getElementById('Q2').style.display = 'none';
    document.getElementById('Q3').style.display = 'none';
    document.getElementById('Q4').style.display = 'none';
    document.getElementById('Q5').style.display = 'none';
    document.getElementById(div_id).style.display = 'block';
};
showOfficer = function(div_id) {
   document.getElementById('OfficerOne').style.display = 'none';
   document.getElementById('OfficerTwo').style.display = 'none';
   document.getElementById('OfficerThree').style.display = 'none';
   document.getElementById('OfficerFour').style.display = 'none';
   document.getElementById(div_id).style.display = 'block';
};
function search() {
 var input, filter, ul, li, a, i, txtValue;
 input = document.getElementById('myInput');
 filter = input.value.toUpperCase();
 ul = document.getElementById("myUL");
 li = ul.getElementsByTagName('li');
 for(i = 0; i < li.length; i++) {
   a = li[i].getElementsByTagName("a")[0];
   txtValue = a.textContent || a.innerText;
   if (txtValue.toUpperCase().indexOf(filter) > -1) {
     li[i].style.display = "";
   }
   else {
     li[i].style.display = "none";
   }
 }
}
function openModal() {
  document.getElementById('myModal').style.display = "block";
}
function closeModal() {
  document.getElementById('myModal').style.display = "none";
}
var slideIndex = 1;
showSlides(slideIndex);
function plusSlides(n) {
  showSlides(slideIndex += n);
}
function currentSlide(n) {
  showSlides(slideIndex = n);
}
function showSlides(n) {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  var dots = document.getElementsByClassName("demo");
  var captionText = document.getElementById("caption");
  if (n > slides.length) {slideIndex = 1;}
  if (n < 1) {slideIndex = slides.length;}
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  for (i = 0; i < dots.length; i++) {
    dots[i].className = dots[i].className.replace(" active", "");
  }
  slides[slideIndex-1].style.display = "block";
  dots[slideIndex-1].className += " active";
  captionText.innerHTML = dots[slideIndex-1].alt;
}
